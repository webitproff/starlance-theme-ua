<?php
/**
 * Russian Language File for the Index Page Module (index.ru.lang.php)
 *
 * @package Index
 * @copyright (c) Cotonti Team
 * @license https://github.com/Cotonti/Cotonti/blob/master/License.txt
 */

defined('COT_CODE') or die('Wrong URL.');

/**
 * Index Page Config
 */

$L['info_desc'] = 'Модуль главной страницы';
