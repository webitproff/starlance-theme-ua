DROP TABLE IF EXISTS `cot_cwsender_letters`;
DROP TABLE IF EXISTS `cot_cwsender_letters_recipients`;
DROP TABLE IF EXISTS `cot_cwsender_lists`;
DROP TABLE IF EXISTS `cot_cwsender_lists_recipients`;