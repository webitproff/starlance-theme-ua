<?php
/* ====================
[BEGIN_COT_EXT]
Code=cwsender
Name=Cwsender
Description=Email-marketing manager
Version=1.0.4
Date=2013-08-08
Author=CMSWorks Team
Copyright=(c) CMSWorks Team 2010-2014
Notes=BSD License
Auth_guests=R
Lock_guests=WA
Auth_members=
Lock_members=
Admin_icon=cwsender.png
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
 * limittosend=01:string::10:Количество отправленных сообщений за один цикл
[END_COT_EXT_CONFIG]
==================== */
