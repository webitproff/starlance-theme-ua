<?php
/**
 * Russian Language File for the Account Module (account.ua.lang.php)
 *
 * @package account
 * @version 1.0.0
 * @author 
 * @copyright Copyright (c)
 * @license BSD
 */

defined('COT_CODE') or die('Wrong URL.');

/**
 * Module Config
 */

$L['info_desc'] = 'Особистий кабінет';

$L['account_account'] = 'Особистий кабінет';
$L['cfg_redirect']  = "Перенаправляти в кабінет <br><small> з головной сторрінки,якщо користувач авторизований </small>";
$L['account_home']  = "Панель інформації";
$L['Profile_Account_Set']  = "Мої налаштування аккаунта";
