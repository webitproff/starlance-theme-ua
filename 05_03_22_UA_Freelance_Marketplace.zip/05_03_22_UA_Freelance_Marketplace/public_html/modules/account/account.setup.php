<?php
/* ====================
[BEGIN_COT_EXT]
Name=Account
Description=User private account page
Version=1.0.1
Date=
Author=
Copyright=(c) 
Notes=
Auth_guests=R
Lock_guests=A
Auth_members=RW1
Lock_members=
Requires_plugins=
Requires_modules=payments,market,page
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
redirect=01:radio:0::Перенаправлять с главной
[END_COT_EXT_CONFIG]
==================== */
