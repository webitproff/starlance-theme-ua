<?php

/**
 * Profile API
 *
 * @package account
 * @version 1.0.0
 * @author
 * @copyright Copyright (c)
 * @license BSD
 */
defined("COT_CODE") or die("Wrong URL.");


/* Requirements */
require_once cot_langfile('account', 'module');


