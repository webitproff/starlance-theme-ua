DROP TABLE IF EXISTS `cot_payments`;
DROP TABLE IF EXISTS `cot_payments_services`;
DROP TABLE IF EXISTS `cot_payments_outs`;
DROP TABLE IF EXISTS `cot_payments_transfers`;