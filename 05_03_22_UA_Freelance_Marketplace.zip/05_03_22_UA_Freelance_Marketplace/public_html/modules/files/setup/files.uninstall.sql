/**
 * PFS database removal
 */

DROP TABLE IF EXISTS `cot_files`, `cot_files_folders`;