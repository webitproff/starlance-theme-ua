files
=====

Files module for Cotonti

Russian documentation: http://lily-software.com/free-scripts/cotonti-files
