<?php

/**
 * [BEGIN_COT_EXT]
 * Hooks=global
 * [END_COT_EXT]
 */

/**
 * services module
 */

defined('COT_CODE') or die('Wrong URL.');

require_once cot_incfile('services', 'module');
require_once cot_incfile('payments', 'module');