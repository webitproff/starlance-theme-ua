/**
 * PFS database removal
 */

DROP TABLE IF EXISTS `cot_pfs`;
DROP TABLE IF EXISTS `cot_pfs_folders`;