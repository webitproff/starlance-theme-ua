<?php
/* ====================
[BEGIN_COT_EXT]
Name=Notifier
Category=community-social
Description=Automatic email notifications
Version=0.9.11
Date=2012-07-07
Author=GHengeveld
Copyright=(c) Cotonti Team 2008-2011
Notes=BSD License
Auth_guests=
Lock_guests=RW12345A
Auth_members=RW1
Lock_members=2345
Admin_icon=
Recommends_modules=forums,pm
Recommends_plugins=comments
[END_COT_EXT]

[BEGIN_COT_EXT_CONFIG]
[END_COT_EXT_CONFIG]
==================== */

?>