DROP TABLE IF EXISTS `cot_notifier_subscriptions`;
DROP TABLE IF EXISTS `cot_notifier_settings`;