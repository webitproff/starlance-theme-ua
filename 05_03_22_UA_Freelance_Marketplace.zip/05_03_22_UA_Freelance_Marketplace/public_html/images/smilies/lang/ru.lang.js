// Russian tips for smilies
var smileL = {
	"smile": 		"Улыбка",
	"happy": 		"Счастлив",
	"sad": 			"Грустный",
	"wink": 		"Подмигивает",
	"grin": 		"Голливудская улыбка",
	"surprised":	"Удивлён",
	"tongue":		"Показывает язык",
	"confused":		"Смущён",
	"sunglasses":	"Тёмные очки",
	"angry":		"Злой",
	"inlove":		"Влюблён",
	"sleeping":		"Спит",
	"rose":			"Роза",
	"angel":		"Ангел",
	"devil":		"Дьявол",
	"kiss":			"Поцелуй"
};