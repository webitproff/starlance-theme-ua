// Ukrainian tips for smilies
var smileL = {
	"smile": 		"Посмішка",
	"happy": 		"Щасливий",
	"sad": 			"Сумний",
	"wink": 		"Підморгує",
	"grin": 		"Голлівудська посмішка",
	"surprised":	"Здивований",
	"tongue":		"Показує язик",
	"confused":		"Збентежений",
	"sunglasses":	"Темні окуляри",
	"angry":		"Злий",
	"inlove":		"Закоханий",
	"sleeping":		"Спить",
	"rose":			"Троянда",
	"angel":		"Ангел",
	"devil":		"Диявол",
	"kiss":			"Поцілунок"
};